import torch
import torch.nn as nn

from timm.models.layers import trunc_normal_
import math

class ModalityScores(nn.Module):
    def __init__(self, embed_dim=384, num_modals=4):
        super().__init__()
        self.num_modals = num_modals
        self.score_nets = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(embed_dim, embed_dim, 3, 1, 1, groups=embed_dim),  # 深度可分离卷积
                nn.Conv2d(embed_dim, 1, 1),  # 降维到 1 通道
                nn.AdaptiveAvgPool2d(1),  # 全局池化 -> [B, 1, 1, 1]
                
                nn.Flatten(),  # 变成 [B, 1]
                nn.Sigmoid()  # 归一化到 (0,1)
            ) for _ in range(num_modals)
        ])

    def forward(self, features_list):
        """
        Args:
            features_list: List of tensors with shape [B, C, H, W]
        Returns:
            scores: Tensor with shape [B, N] where N is num_modals
        """
        scores = [net(feat) for net, feat in zip(self.score_nets, features_list)]
        scores = torch.cat(scores, dim=1)  # [B, num_modals]
        return scores


# Feature Rectify Module
class ChannelWeights(nn.Module):
    def __init__(self, dim, num_modals, reduction=1):
        super(ChannelWeights, self).__init__()
        self.dim = dim
        self.num_modals = num_modals
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.mlp = nn.Sequential(
                    nn.Linear(self.dim * self.num_modals * 2, self.dim * self.num_modals * 2 // reduction),
                    nn.ReLU(inplace=True),
                    nn.Linear(self.dim * self.num_modals * 2 // reduction, self.dim * self.num_modals), 
                    nn.Sigmoid())

    def forward(self, x_list):
        B, _, H, W = x_list[0].shape
        x = torch.cat(x_list, dim=1)
        avg = self.avg_pool(x).view(B, self.dim * self.num_modals)
        max = self.max_pool(x).view(B, self.dim * self.num_modals) # B, num_modals * C, H, W
        y = torch.cat((avg, max), dim=1) # B 2*num_modals*C
        y = self.mlp(y).view(B, self.dim * self.num_modals, 1)
        channel_weights = y.reshape(B, self.num_modals, self.dim, 1, 1).permute(1, 0, 2, 3, 4) # 2 B C 1 1
        return channel_weights


class SpatialWeights(nn.Module):
    def __init__(self, dim, reduction=1, num_modals=2):
        super(SpatialWeights, self).__init__()
        self.dim = dim
        self.num_modals = num_modals
        self.mlp = nn.Sequential(
                    nn.Conv2d(self.dim * self.num_modals, self.dim // reduction, kernel_size=1),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(self.dim // reduction, num_modals, kernel_size=1), 
                    nn.Sigmoid())

    def forward(self, x_list):
        B, _, H, W = x_list[0].shape
        x = torch.cat(x_list, dim=1) # B num_modals*C H W
        spatial_weights = self.mlp(x).reshape(B, self.num_modals, 1, H, W).permute(1, 0, 2, 3, 4) # 2 B 1 H W
        return spatial_weights


class ModalityDrop(nn.Module):
    def __init__(self, dim, num_modals=2, reduction=1, lambda_c=.5, lambda_s=.5):
        super(ModalityDrop, self).__init__()
        self.lambda_c = lambda_c
        self.lambda_s = lambda_s
        self.num_modals = num_modals
        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.channel_weights = ChannelWeights(dim=dim, num_modals=num_modals, reduction=reduction)
        self.spatial_weights = SpatialWeights(dim=dim, num_modals=num_modals, reduction=reduction)
    
    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()
    
    def forward(self, x_list, drop_idx):
        """
        Args:
            x_list: 4个模态的特征 [B, C, H, W]
            drop_idx: 需要删除的模态索引
        Returns:
            outputs: 经过信息融合后的 3 个模态
        """
        B = x_list[0].shape[0]
        channel_weights = self.channel_weights(x_list)
        spatial_weights = self.spatial_weights(x_list)
        outputs = []


        for i in range(self.num_modals):
            if i == drop_idx:  # 不直接输出被删除的模态，但仍可参与信息传递
                continue
            modulated_feature = x_list[i]
            for j in range(self.num_modals):
                ''' if i == max_idx and j == drop_idx:
                    enhanced_feature = self.alpha * channel_weights[j] * x_list[j] + self.alpha * spatial_weights[j] * x_list[j]
                    modulated_feature = modulated_feature + enhanced_feature'''
                if j != i:  # 只在剩余的模态中传递信息
                    modulated_feature = modulated_feature + self.lambda_c * channel_weights[j] * x_list[j] + self.lambda_s * spatial_weights[j] * x_list[j]
            outputs.append(modulated_feature)
        return outputs



if __name__ == '__main__':
    x = [torch.zeros(4, 32, 256, 256), torch.ones(4, 32, 256, 256), torch.ones(4, 32, 256, 256)*2, torch.ones(4, 32, 256, 256) *3]
    score_net = ModalityScores(32, 4)
    scores = score_net(x)
    mean_scores = scores.mean(dim=0)
    max_idx = torch.argmax(mean_scores).item()
    drop_idx = torch.argmin(mean_scores).item()
    modality_drop = ModalityDrop(dim=32, reduction=1, num_modals=4)
    x_ls = modality_drop(x, drop_idx)
    print(len(x_ls))

    


