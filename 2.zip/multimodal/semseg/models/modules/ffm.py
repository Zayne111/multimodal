import torch
import torch.nn as nn

from timm.models.layers import trunc_normal_
import math


# Feature Rectify Module
class ChannelWeights(nn.Module):
    def __init__(self, dim, num_modals, reduction=1):
        super(ChannelWeights, self).__init__()
        self.dim = dim
        self.num_modals = num_modals
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.mlp = nn.Sequential(
                    nn.Linear(self.dim * self.num_modals * 2, self.dim * self.num_modals * 2 // reduction),
                    nn.ReLU(inplace=True),
                    nn.Linear(self.dim * self.num_modals * 2 // reduction, self.dim * self.num_modals), 
                    nn.Sigmoid())

    def forward(self, x_list):
        B, _, H, W = x_list[0].shape
        x = torch.cat(x_list, dim=1)
        avg = self.avg_pool(x).view(B, self.dim * self.num_modals)
        max = self.max_pool(x).view(B, self.dim * self.num_modals) # B, num_modals * C, H, W
        y = torch.cat((avg, max), dim=1) # B 2*num_modals*C
        y = self.mlp(y).view(B, self.dim * self.num_modals, 1)
        channel_weights = y.reshape(B, self.num_modals, self.dim, 1, 1).permute(1, 0, 2, 3, 4) # 2 B C 1 1
        return channel_weights


class SpatialWeights(nn.Module):
    def __init__(self, dim, reduction=1, num_modals=2):
        super(SpatialWeights, self).__init__()
        self.dim = dim
        self.num_modals = num_modals
        self.mlp = nn.Sequential(
                    nn.Conv2d(self.dim * self.num_modals, self.dim // reduction, kernel_size=1),
                    nn.ReLU(inplace=True),
                    nn.Conv2d(self.dim // reduction, num_modals, kernel_size=1), 
                    nn.Sigmoid())

    def forward(self, x_list):
        B, _, H, W = x_list[0].shape
        x = torch.cat(x_list, dim=1) # B num_modals*C H W
        spatial_weights = self.mlp(x).reshape(B, self.num_modals, 1, H, W).permute(1, 0, 2, 3, 4) # 2 B 1 H W
        return spatial_weights


class FeatureRectifyModule(nn.Module):
    def __init__(self, dim, num_modals=2, reduction=1, lambda_c=.5, lambda_s=.5):
        super(FeatureRectifyModule, self).__init__()
        self.lambda_c = lambda_c
        self.lambda_s = lambda_s
        self.num_modals = num_modals
        self.channel_weights = ChannelWeights(dim=dim, num_modals=num_modals, reduction=reduction)
        self.spatial_weights = SpatialWeights(dim=dim, num_modals=num_modals, reduction=reduction)
    
    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()
    
    def forward(self, x_list):
        channel_weights = self.channel_weights(x_list)
        spatial_weights = self.spatial_weights(x_list)
        outputs = []
        for i in range(self.num_modals):
            modulated_feature = x_list[i]  # 当前模态的特征
            for j in range(self.num_modals):
                if i != j:  # 让模态 i 受到其他模态 j 的影响
                    modulated_feature = modulated_feature + self.lambda_c * channel_weights[j] * x_list[j]
                    modulated_feature = modulated_feature + self.lambda_s * spatial_weights[j] * x_list[j]
            outputs.append(modulated_feature)
        return outputs


# Stage 1
class CrossAttention(nn.Module):
    def __init__(self, dim, num_heads=8, num_modals=4, qkv_bias=False, qk_scale=None):
        super(CrossAttention, self).__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.num_heads = num_heads
        self.num_modals = num_modals
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5
        self.kv_layers = nn.ModuleList([nn.Linear(dim, dim * 2, bias=qkv_bias) for _ in range(num_modals)])

    def forward(self, x_list):
        B, N, C = x_list[0].shape
        q_list = [x.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous() for x in x_list]
        kv_list = [self.kv_layers[i](x).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4).contiguous() for i, x in enumerate(x_list)]
        attn_list = []
        for i in range(self.num_modals):
            ctx = sum((kv_list[j][0].transpose(-2, -1) @ kv_list[j][1]) * self.scale for j in range(self.num_modals) if j != i)
            ctx = ctx.softmax(dim=-2)
            attn_list.append((q_list[i] @ ctx).permute(0, 2, 1, 3).reshape(B, N, C).contiguous())

        return attn_list


class CrossPath(nn.Module):
    def __init__(self, dim, num_modals=4, reduction=1, num_heads=None, norm_layer=nn.LayerNorm):
        super().__init__()
        self.num_modals = num_modals
        self.channel_proj = nn.ModuleList([nn.Linear(dim, dim // reduction * 2) for _ in range(num_modals)])
        self.act = nn.ReLU(inplace=True)
        self.cross_attn = CrossAttention(dim // reduction, num_heads=num_heads, num_modals=num_modals)
        self.end_proj = nn.ModuleList([nn.Linear(dim // reduction * 2, dim) for _ in range(num_modals)])
        self.norm = nn.ModuleList([norm_layer(dim) for _ in range(num_modals)])

    def forward(self, x_list):
        y_list = []
        u_list = []
        for i in range(self.num_modals):
            y, u = self.act(self.channel_proj[i](x_list[i])).chunk(2, dim=-1)
            y_list.append(y)
            u_list.append(u)
        v_list = self.cross_attn(u_list)
        output_list = []
        for i in range(self.num_modals):
            merged = torch.cat((y_list[i], v_list[i]), dim=-1)
            output_list.append(self.norm[i](x_list[i] + self.end_proj[i](merged)))
        return output_list


# Stage 2
class ChannelEmbed(nn.Module):
    def __init__(self, in_channels, out_channels, reduction=1, norm_layer=nn.BatchNorm2d):
        super(ChannelEmbed, self).__init__()
        self.out_channels = out_channels
        self.residual = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        self.channel_embed = nn.Sequential(
                        nn.Conv2d(in_channels, out_channels//reduction, kernel_size=1, bias=True),
                        nn.Conv2d(out_channels//reduction, out_channels//reduction, kernel_size=3, stride=1, padding=1, bias=True, groups=out_channels//reduction),
                        nn.ReLU(inplace=True),
                        nn.Conv2d(out_channels//reduction, out_channels, kernel_size=1, bias=True),
                        norm_layer(out_channels) 
                        )
        self.norm = norm_layer(out_channels)
        
    def forward(self, x, H, W):
        B, N, _C = x.shape
        x = x.permute(0, 2, 1).reshape(B, _C, H, W).contiguous()
        residual = self.residual(x)
        x = self.channel_embed(x)
        out = self.norm(residual + x)
        return out


class FeatureFusionModule(nn.Module):
    def __init__(self, dim, num_modals=2, reduction=1, num_heads=None, norm_layer=nn.BatchNorm2d):
        super().__init__()
        self.cross = CrossPath(dim=dim, reduction=reduction, num_heads=num_heads, num_modals=num_modals)
        self.channel_emb = ChannelEmbed(in_channels=dim*num_modals, out_channels=dim, reduction=reduction, norm_layer=norm_layer)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x_ls):
        B, C, H, W = x_ls[0].shape
        x_flattened = [x.flatten(2).transpose(1, 2) for x in x_ls]
        atten = self.cross(x_flattened)
        merge = torch.cat(atten, dim=-1)
        merge = self.channel_emb(merge, H, W)
        
        return merge
    
if __name__ == '__main__':
    modals = ['img', 'depth', 'event', 'lidar']
    x = [torch.zeros(1, 64, 256, 256), torch.ones(1, 64, 256, 256), torch.ones(1, 64, 256, 256)*2, torch.ones(1, 64, 256, 256) *3]
    frm = FeatureRectifyModule(64, num_modals=4)
    ffm = FeatureFusionModule(64, num_modals=4, num_heads=1, norm_layer=nn.BatchNorm2d)
    x = frm(x)
    x = ffm(x)
    print(x.shape)