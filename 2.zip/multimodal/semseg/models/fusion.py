import torch
from torch import nn
from torch.nn import functional as F
import yaml
from fvcore.nn import FlopCountAnalysis
from semseg.models.heads import SegFormerHead
from semseg.models.base import BaseModel    


class Fusion(BaseModel):
    def __init__(self, backbone: str = 'Fusion-B0', num_classes: int = 19, modals: list = ['img', 'depth', 'event', 'lidar']):
        super().__init__(backbone, num_classes, modals)
        self.decode_head = SegFormerHead(self.backbone.channels, 256 if 'B0' in backbone or 'B1' in backbone else 512, num_classes)
        self.apply(self._init_weights)

    def forward(self, x):
        y = self.backbone(x)
        y = self.decode_head(y)
        y = F.interpolate(y, size=x[0].shape[2:], mode='bilinear', align_corners=False)
        #y = y.mean(dim=0, keepdim=True)
        return y

    def init_pretrained(self, pretrained: str = None) -> None:
        checkpoint = torch.load(pretrained, map_location='cpu')
        #print("Checkpoint Keys:", checkpoint.keys())  # 查看所有 key
        if 'state_dict' in checkpoint.keys():
            checkpoint = checkpoint['state_dict']
        if 'model' in checkpoint.keys():
            checkpoint = checkpoint['model']
        model_dict = self.backbone.state_dict()
        pretrained_dict = {k: v for k, v in checkpoint.items() if k in model_dict and v.shape == model_dict[k].shape}
        model_dict.update(pretrained_dict)
        msg = self.backbone.load_state_dict(checkpoint, strict=False)
        print("Missing keys:", msg.missing_keys)
        print("Unexpected keys:", msg.unexpected_keys)
        print(msg)





if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    modals = ['img', 'depth', 'event', 'lidar']

    #model = MutiModalTransformer(backbone=model_cfg['BACKBONE'], num_classes=25).to(device)
    model = Fusion(backbone='Fusion-B0', num_classes=25, modals=modals).to(device)
    print(model)
    
    # pretrained_weights = '1/output/MCubeS_MutiModalTransformer-B0_iadn/MutiModalTransformer_MutiModalTransformer-B0_MCubeS_epoch411_31.64.pth'
    # pretrained_weights = '1/pretrained/mit_b0_20220624-7e0fe6dd.pth'
    pretrained_weights = '/Users/zhangzelin/Documents/code/2/pretrained/mit_b2_20220624-66e8bf70.pth'
    model.init_pretrained(pretrained=pretrained_weights)


    x = [torch.zeros(4, 3, 1024, 1024), torch.ones(4, 3, 1024, 1024), torch.ones(4, 3, 1024, 1024)*2, torch.ones(4, 3, 1024, 1024) *3]
    x = [tensor.to(device) for tensor in x] 
    y = model(x)
    print(y.shape) 

