import math
import warnings

import torch
from torch import nn, Tensor
import torch.utils.checkpoint as cp
from mmcv.cnn import Conv2d, build_activation_layer, build_norm_layer
from mmcv.cnn.bricks.drop import build_dropout
from mmcv.cnn.bricks.transformer import MultiheadAttention
from mmengine.model import BaseModule, ModuleList, Sequential
from mmengine.model.weight_init import (constant_init, normal_init,
                                        trunc_normal_init)

from semseg.models.modules.utils import nlc_to_nchw, nchw_to_nlc, PatchEmbed
from semseg.models.modules.modality_drop import ModalityDrop, ModalityScores



class MixFFN(BaseModule):
    def __init__(self,
                 embed_dims,
                 feedforward_channels,
                 act_cfg=dict(type='GELU'),
                 ffn_drop=0.,
                 dropout_layer=None,
                 init_cfg=None):
        super().__init__(init_cfg)

        self.embed_dims = embed_dims
        self.feedforward_channels = feedforward_channels
        self.act_cfg = act_cfg
        self.activate = build_activation_layer(act_cfg)

        in_channels = embed_dims
        fc1 = Conv2d(
            in_channels=in_channels,
            out_channels=feedforward_channels,
            kernel_size=1,
            stride=1,
            bias=True)
        # 3x3 depth wise conv to provide positional encode information
        pe_conv = Conv2d(
            in_channels=feedforward_channels,
            out_channels=feedforward_channels,
            kernel_size=3,
            stride=1,
            padding=(3 - 1) // 2,
            bias=True,
            groups=feedforward_channels)
        fc2 = Conv2d(
            in_channels=feedforward_channels,
            out_channels=in_channels,
            kernel_size=1,
            stride=1,
            bias=True)
        drop = nn.Dropout(ffn_drop)
        layers = [fc1, pe_conv, self.activate, drop, fc2, drop]
        self.layers = Sequential(*layers)
        self.dropout_layer = build_dropout(
            dropout_layer) if dropout_layer else torch.nn.Identity()

    def forward(self, x, hw_shape, identity=None):
        out = nlc_to_nchw(x, hw_shape)
        out = self.layers(out)
        out = nchw_to_nlc(out)
        if identity is None:
            identity = x
        return identity + self.dropout_layer(out)


class Attention(MultiheadAttention):
    def __init__(self,
                 embed_dims,
                 num_heads,
                 attn_drop=0.,
                 proj_drop=0.,
                 dropout_layer=None,
                 init_cfg=None,
                 batch_first=True,
                 qkv_bias=False,
                 norm_cfg=dict(type='LN'),
                 sr_ratio=1):
        super().__init__(
            embed_dims,
            num_heads,
            attn_drop,
            proj_drop,
            dropout_layer=dropout_layer,
            init_cfg=init_cfg,
            batch_first=batch_first,
            bias=qkv_bias)

        self.sr_ratio = sr_ratio
        if sr_ratio > 1:
            self.sr = Conv2d(
                in_channels=embed_dims,
                out_channels=embed_dims,
                kernel_size=sr_ratio,
                stride=sr_ratio)
            # The ret[0] of build_norm_layer is norm name.
            self.norm = build_norm_layer(norm_cfg, embed_dims)[1]

    def forward(self, x, hw_shape, identity=None):

        x_q = x
        if self.sr_ratio > 1:
            x_kv = nlc_to_nchw(x, hw_shape)
            x_kv = self.sr(x_kv)
            x_kv = nchw_to_nlc(x_kv)
            x_kv = self.norm(x_kv)
        else:
            x_kv = x

        if identity is None:
            identity = x_q

        if self.batch_first:
            x_q = x_q.transpose(0, 1)
            x_kv = x_kv.transpose(0, 1)

        out = self.attn(query=x_q, key=x_kv, value=x_kv)[0]

        if self.batch_first:
            out = out.transpose(0, 1)

        return identity + self.dropout_layer(self.proj_drop(out))

    def legacy_forward(self, x, hw_shape, identity=None):
        x_q = x
        if self.sr_ratio > 1:
            x_kv = nlc_to_nchw(x, hw_shape)
            x_kv = self.sr(x_kv)
            x_kv = nchw_to_nlc(x_kv)
            x_kv = self.norm(x_kv)
        else:
            x_kv = x

        if identity is None:
            identity = x_q

        out = self.attn(query=x_q, key=x_kv, value=x_kv, need_weights=False)[0]

        return identity + self.dropout_layer(self.proj_drop(out))


class EncoderLayer(BaseModule):
    def __init__(self,
                 embed_dims,
                 num_heads,
                 feedforward_channels,
                 drop_rate=0.,
                 attn_drop_rate=0.,
                 drop_path_rate=0.,
                 qkv_bias=True,
                 act_cfg=dict(type='GELU'),
                 norm_cfg=dict(type='LN'),
                 batch_first=True,
                 sr_ratio=1,
                 with_cp=False):
        super().__init__()

        # The ret[0] of build_norm_layer is norm name.
        self.norm1 = build_norm_layer(norm_cfg, embed_dims)[1]

        self.attn = Attention(
            embed_dims=embed_dims,
            num_heads=num_heads,
            attn_drop=attn_drop_rate,
            proj_drop=drop_rate,
            dropout_layer=dict(type='DropPath', drop_prob=drop_path_rate),
            batch_first=batch_first,
            qkv_bias=qkv_bias,
            norm_cfg=norm_cfg,
            sr_ratio=sr_ratio)

        # The ret[0] of build_norm_layer is norm name.
        self.norm2 = build_norm_layer(norm_cfg, embed_dims)[1]

        self.ffn = MixFFN(
            embed_dims=embed_dims,
            feedforward_channels=feedforward_channels,
            ffn_drop=drop_rate,
            dropout_layer=dict(type='DropPath', drop_prob=drop_path_rate),
            act_cfg=act_cfg)

        self.with_cp = with_cp

    def forward(self, x, hw_shape):

        def _inner_forward(x):
            H, W = hw_shape
            x = self.attn(self.norm1(x), hw_shape, identity=x)
            x = self.ffn(self.norm2(x), hw_shape, identity=x)
            return x

        if self.with_cp and x.requires_grad:
            x = cp.checkpoint(_inner_forward, x)
        else:
            x = _inner_forward(x)
        return x

settings = {
    'B0': [32, [2, 2, 2, 2]],
    'B1': [64, [2, 2, 2, 2]],
    'B2': [64, [3, 4, 6, 3]],
    'B3': [64, [3, 4, 18, 3]],
    'B4': [64, [3, 8, 27, 3]],
    'B5': [64, [3, 6, 40, 3]]
}
    

class Fusion(BaseModule):
    def __init__(self, model_name: str = 'B2', modals: list = ['rgb', 'depth', 'event', 'lidar']):
        super().__init__()

        in_channels = 3
        embed_dims = settings[model_name][0]
        num_stages = 4
        num_layers = settings[model_name][1]
        num_heads = [1, 2, 5, 8]
        patch_sizes = [7, 3, 3, 3]
        strides = [4, 2, 2, 2]
        sr_ratios = [8, 4, 2, 1]
        out_indices = (0, 1, 2, 3)
        mlp_ratio = 4
        qkv_bias = True
        drop_rate = 0.
        attn_drop_rate = 0.
        drop_path_rate = 0.
        act_cfg = dict(type='GELU')
        norm_cfg = dict(type='LN', eps=1e-6)
        with_cp = False
        num_modals = len(modals)

        self.num_modals = num_modals
        self.num_stages = num_stages
        self.out_indices = out_indices
        channels = [
            int(embed_dims * num_heads[0]),
            int(embed_dims * num_heads[1]),
            int(embed_dims * num_heads[2]),
            int(embed_dims * num_heads[3])
        ]

        self.channels = channels

        # Transformer Encoder
        dpr = [
            x.item()
            for x in torch.linspace(0, drop_path_rate, sum(num_layers))
        ]        
        cur = 0

        self.layers = ModuleList()
        for i, num_layer in enumerate(num_layers):
            embed_dims_i = embed_dims * num_heads[i]
            num_modal_stage = max(num_modals - i, 1)
            patch_embed = PatchEmbed(
                in_channels=in_channels if i==0 else embed_dims * num_heads[i-1],
                #in_channels=in_channels if i == 0 else embed_dims * num_heads[i - 1] // self.num_modals,
                embed_dims=embed_dims_i,
                kernel_size=patch_sizes[i],
                stride=strides[i],
                padding=patch_sizes[i] // 2,
                norm_cfg=norm_cfg)
            scores_net = ModalityScores(
                embed_dim=embed_dims_i,
                num_modals=num_modal_stage # num_modals-i if num_modals>0 else 1
            )
            modalitydrop = ModalityDrop(
                dim=embed_dims_i,
                num_modals=num_modal_stage,# num_modals-i if num_modals>0 else 1,
                reduction=1
            )
            layer = ModuleList([
                EncoderLayer(
                    embed_dims=embed_dims_i,
                    num_heads=num_heads[i],
                    feedforward_channels=mlp_ratio * embed_dims_i,
                    drop_rate=drop_rate,
                    attn_drop_rate=attn_drop_rate,
                    drop_path_rate=dpr[cur + idx],
                    qkv_bias=qkv_bias,
                    act_cfg=act_cfg,
                    norm_cfg=norm_cfg,
                    with_cp=with_cp,
                    sr_ratio=sr_ratios[i]) for idx in range(num_layer)
            ])
            norm = build_norm_layer(norm_cfg, embed_dims_i)[1]
            self.layers.append(ModuleList([patch_embed, layer, norm, scores_net, modalitydrop]))
            cur += num_layer


    def forward(self, x):
        B, C, H, W = x[0].shape
        num_modals_input = len(x)
        #stage 1
        out = []
        out_1 = []
        for x_m in x:
            x_m, hw_shape = self.layers[0][0](x_m)
            for block in self.layers[0][1]:
                x_m = block(x_m, hw_shape)
            x_m = self.layers[0][2](x_m)
            x_m = nlc_to_nchw(x_m, hw_shape)
            out_1.append(x_m)
        if num_modals_input >= 2:
            scores = self.layers[0][3](out_1)
            mean_scores = scores.mean(dim=0)
            drop_idx = torch.argmin(mean_scores).item()
            out_1 = self.layers[0][4](out_1, drop_idx)
            x_1 = torch.mean(torch.stack(out_1, dim=0), dim=0)
            out.append(x_1)
        else:
            out.append(x_m)
        
        #stage2
        out_2 = []
        for x_m in out_1:
            x_m, hw_shape = self.layers[1][0](x_m)
            for block in self.layers[1][1]:
                x_m = block(x_m, hw_shape)
            x_m = self.layers[1][2](x_m)
            x_m = nlc_to_nchw(x_m, hw_shape)
            out_2.append(x_m)
        if num_modals_input >= 3:
            scores = self.layers[1][3](out_2)
            mean_scores = scores.mean(dim=0)
            drop_idx = torch.argmin(mean_scores).item()
            out_2 = self.layers[1][4](out_2, drop_idx)
            x_2 = torch.mean(torch.stack(out_2, dim=0), dim=0)
            out.append(x_2)
        else:
            out.append(x_m)
        
        #stage3
        out_3 = []
        for x_m in out_2:
            x_m, hw_shape = self.layers[2][0](x_m)
            for block in self.layers[2][1]:
                x_m = block(x_m, hw_shape)
            x_m = self.layers[2][2](x_m)
            x_m = nlc_to_nchw(x_m, hw_shape)
            out_3.append(x_m)
        if num_modals_input >= 4:
            scores = self.layers[2][3](out_3)
            mean_scores = scores.mean(dim=0)
            drop_idx = torch.argmin(mean_scores).item()
            out_3 = self.layers[2][4](out_3, drop_idx)
            out.append(out_3[0])
        else:
            out.append(x_m)
        
        #stage4 
        for x_m in out_3:
            x_m, hw_shape = self.layers[3][0](x_m)
            for block in self.layers[3][1]:
                x_m = block(x_m, hw_shape)
            x_m = self.layers[3][2](x_m)
            x_m = nlc_to_nchw(x_m, hw_shape)
        out.append(x_m)
        return out
    

    
if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    modals = ['img', 'depth']
    x = [torch.ones(1, 3, 1024, 1024), torch.ones(1, 3, 1024, 1024)]
    x = [tensor.to(device) for tensor in x] 
    model = Fusion('B2', modals).to(device)
    outs = model(x)
    for y in outs:
        print(y.shape)
