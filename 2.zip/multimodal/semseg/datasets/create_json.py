import os
import json
import numpy as np
import cv2
from tqdm import tqdm

# 设置路径（根据你截图所示结构）
root = '/Users/zhangzelin/Documents/data/Mcubes/multimodal_dataset'  # 替换为你的实际路径
gt_dir = os.path.join(root, 'GT')
train_list = os.path.join(root, 'list_folder/train.txt')
output_dir = root

NUM_CLASSES = 20  # MCubeS 有 20 个类

# 1. 读取训练文件名列表
with open(train_list, 'r') as f:
    file_names = [line.strip().split(' ')[0] for line in f.readlines()]

# 初始化结果
sample_class_stats = []
samples_with_class = {str(i): [] for i in range(NUM_CLASSES)}

# 2. 遍历每一张图
for name in tqdm(file_names, desc="Processing GT"):
    gt_path = os.path.join(gt_dir, name + '.png')
    label = cv2.imread(gt_path, cv2.IMREAD_GRAYSCALE)

    class_stats = {}
    for cls in range(NUM_CLASSES):
        count = int(np.sum(label == cls))
        if count > 0:
            class_stats[str(cls)] = count
            samples_with_class[str(cls)].append([name + '.png', count])

    sample_class_stats.append({
        "file": name + '.png',
        **class_stats
    })

# 3. 保存两个 JSON
with open(os.path.join(output_dir, 'sample_class_stats.json'), 'w') as f:
    json.dump(sample_class_stats, f, indent=2)

with open(os.path.join(output_dir, 'samples_with_class.json'), 'w') as f:
    json.dump(samples_with_class, f, indent=2)

print("✅ Done: 生成 sample_class_stats.json 和 samples_with_class.json 成功！")
