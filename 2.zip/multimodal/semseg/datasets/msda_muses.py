import os
import torch
import numpy as np
from torch import Tensor
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms.functional as TF
from torchvision import io
from typing import Tuple, List
import glob
from PIL import Image
import torch.nn.functional as F
from semseg.augmentations_mm import get_train_augmentation
import yaml


class MSDAMUSES(Dataset):
    """
    Dataset for the MUSES multi-modal semantic segmentation dataset with 11 target classes.
    """
    # Subset of target semantic classes
    CLASSES = ['Building', 'Bus', 'Fence', 'Pole', 'Road', 'Sidewalk', 'Sky', 'Terrain', 'Truck', 'Vegetation', 'Wall']

    # Map the original 25-class indices to the 11-class subset
    CLASS_MAP = {
        0: 4,  # Road
        1: 5,  # Sidewalk
        2: 0,  # Building
        3: 10,  # Wall
        4: 2,  # Fence
        5: 3,  # Pole
        6: 255,  # Traffic Light -> Ignored
        7: 255,  # Traffic Sign -> Ignored
        8: 9,  # Vegetation
        9: 7,  # Terrain
        10: 6,  # Sky
        11: 255,  # Person -> Ignored
        12: 255,  # Rider -> Ignored
        13: 255,  # Car -> Ignored
        14: 10,  # Truck
        15: 1,  # Bus
        16: 255,  # Train -> Ignored
        17: 255,  # Motorcycle -> Ignored
        18: 255,  # Bicycle -> Ignored
    }

    def __init__(
        self,
        root: str = '/mnt/dev-ssd-8T/zheng/data/muses/multimodal',
        split: str = 'train',
        transform=None,
        modals: List[str] = ['frame_camera'],
        weather_condition: str = None,
        time_of_day: str = None,
        image_size: Tuple[int, int] = (1024, 1024),
    ) -> None:
        """
        Initialize the dataset.

        Args:
            root (str): Root directory of the dataset.
            split (str): Dataset split ('train', 'val', 'test').
            transform: Data augmentation/transformation.
            modals (List[str]): List of modalities to load (e.g., 'frame_camera', 'lidar').
            weather_condition (str): Filter by weather condition ('clear', 'fog', 'rain', 'snow').
            time_of_day (str): Filter by time of day ('day', 'night').
            image_size (Tuple[int, int]): Desired image dimensions for resizing.
        """
        super().__init__()
        assert split in ['train', 'val', 'test'], f"Invalid split: {split}. Must be 'train', 'val', or 'test'."
        self.transform = transform
        self.modals = modals
        self.image_size = image_size
        self.ignore_label = 255
        self.n_classes = len(self.CLASSES)

        # Load all files for the specified split
        self.files = sorted(glob.glob(os.path.join(root, 'frame_camera', split, '*', '*', '*.png')))
        if not self.files:
            raise Exception(f"No files found in the dataset root: {root}.")

        # Filter by weather condition
        if weather_condition:
            valid_conditions = ['clear', 'fog', 'rain', 'snow']
            if weather_condition not in valid_conditions:
                raise ValueError(f"Invalid weather condition: {weather_condition}. Must be one of {valid_conditions}.")
            self.files = [f for f in self.files if weather_condition in f]

        # Filter by time of day
        if time_of_day:
            valid_times = ['day', 'night']
            if time_of_day not in valid_times:
                raise ValueError(f"Invalid time of day: {time_of_day}. Must be one of {valid_times}.")
            self.files = [f for f in self.files if time_of_day in f]

        if not self.files:
            raise Exception(f"No files found for split '{split}', weather condition '{weather_condition}', and time of day '{time_of_day}'.")
        print(f"Found {len(self.files)} images for split '{split}' with weather condition '{weather_condition}' and time of day '{time_of_day}'.")

    def __len__(self) -> int:
        return len(self.files)

    def __getitem__(self, index: int) -> Tuple[Tensor, Tensor]:

        # if index < 0 or index >= len(self.files):
        #     print(f"Invalid index: {index}, Dataset size: {len(self.files)}")
        #     raise IndexError(f"Index {index} out of range for dataset of size {len(self.files)}")
        # print(f"Accessing index: {index}, File: {self.files[index]}")

        base_path = str(self.files[index])
        sample = {}

        # Load each modality specified
        for modal in self.modals:
            img_path = base_path.replace('frame_camera', f'{modal}')

            # Use PIL to open the image
            img = Image.open(img_path).convert('RGB')  # Convert to RGB
            img = img.resize(self.image_size)  # Resize to target size
            img_tensor = torch.from_numpy(np.array(img)).permute(2, 0, 1).float() / 255.0  # Convert to float [0, 1]
            sample[modal] = img_tensor

        # Load and process ground truth label
        lbl_path = base_path.replace('/frame_camera', '/gt_semantic').replace('frame_camera', 'gt_labelTrainIds')
        label = io.read_image(lbl_path)[0, ...].unsqueeze(0)  # Load single-channel label
        label = F.interpolate(label.unsqueeze(0), size=self.image_size, mode='nearest').squeeze(1).long()
        label = self.encode(label.squeeze().numpy())  # Map labels to target classes

        sample = [sample[k] for k in self.modals]
        return sample, label

    def encode(self, label: np.ndarray) -> Tensor:
        """
        Encode the ground truth labels to match the 11 target classes.

        Args:
            label (np.ndarray): Input label array.

        Returns:
            Tensor: Encoded label tensor.
        """
        encoded_label = np.full_like(label, self.ignore_label, dtype=np.uint8)
        for original_idx, new_idx in self.CLASS_MAP.items():
            encoded_label[label == original_idx] = new_idx
        return torch.from_numpy(encoded_label)


def test_muses_from_config(cfg_path: str, split: str = 'val', cases=None):
    """
    从 YAML 配置加载 MSDAMUSES 数据集进行测试，并打印标签类别分布。
    :param cfg_path: 配置文件路径
    :param split: 'train' / 'val' / 'test'
    :param cases: 天气或光照过滤条件（列表）
    """
    with open(cfg_path) as f:
        full_cfg = yaml.load(f, Loader=yaml.SafeLoader)
    
    dataset_cfg = full_cfg['DATASET']
    image_size = full_cfg['TRAIN']['IMAGE_SIZE']
    transform = get_train_augmentation(image_size, seg_fill=dataset_cfg['IGNORE_LABEL'])

    if cases is None:
        cases = [None]  # 默认不筛选任何 weather / time

    for case in cases:
        print(f"\n🔍 正在加载数据: case = {case}, split = {split}")
        dataset = MSDAMUSES(
            root=dataset_cfg['ROOT_t'],  # 目标域路径
            split=split,
            transform=transform,
            modals=dataset_cfg['MODALS_t'],
            weather_condition=case if case in ['clear', 'fog', 'rain', 'snow'] else None,
            time_of_day=case if case in ['day', 'night'] else None,
            image_size=tuple(image_size)
        )

        dataloader = DataLoader(dataset, batch_size=2, num_workers=2, shuffle=False, drop_last=False)

        for i, (sample, lbl) in enumerate(dataloader):
            print(f"Batch {i+1}: 标签 shape = {lbl.shape}, 标签类别: {torch.unique(lbl)}")
            if i >= 2:  # 只打印前 3 个 batch
                break

if __name__ == '__main__':
    cfg_file = '/root/2/configs/msda.yaml'
    # 可替换成你感兴趣的 case，比如 ['fog', 'night', 'rain']
    test_cases = ['cloud']  # cloud 是你自定义的，用来测试路径加载
    test_muses_from_config(cfg_file, split='val', cases=test_cases)