import os
import torch 
import numpy as np
from torch import Tensor
from torch.utils.data import Dataset
import torchvision.transforms.functional as TF 
from torchvision import io
from pathlib import Path
from typing import Tuple
import glob
import einops
from torch.utils.data import DataLoader
from torch.utils.data import DistributedSampler, RandomSampler
from semseg.augmentations_mm import get_train_augmentation
import torchvision.transforms as transforms
import yaml

class MSDADELIVER(Dataset):
    """
    Refined Dataset for 11 Classes
    """
    # Desired subset of classes
    CLASSES = ['Building', 'Bus', 'Fence', 'Pole', 'Road', 'Sidewalk', 'Sky', 'Terrain', 'Truck', 'Vegetation', 'Wall']
    
    # Map the original 25-class indices to the 11-class subset
    CLASS_MAP = {
        0: 0,  # Building
        1: 2,  # Fence
        2: 255,  # Other -> Ignored
        3: 255,  # Pedestrian -> Ignored
        4: 3,  # Pole
        5: 255,  # RoadLine -> Ignored
        6: 4,  # Road
        7: 5,  # Sidewalk
        8: 9,  # Vegetation
        9: 255,  # Cars -> Ignored
        10: 10,  # Wall
        11: 255,  # TrafficSign -> Ignored
        12: 6,  # Sky
        13: 255,  # Ground -> Ignored
        14: 255,  # Bridge -> Ignored
        15: 255,  # RailTrack -> Ignored
        16: 255,  # GroundRail -> Ignored
        17: 255,  # TrafficLight -> Ignored
        18: 255,  # Static -> Ignored
        19: 255,  # Dynamic -> Ignored
        20: 255,  # Water -> Ignored
        21: 7,  # Terrain
        22: 255,  # TwoWheeler -> Ignored
        23: 1,  # Bus
        24: 8   # Truck
    }
    
    def __init__(self, root: str = 'data/DELIVER', split: str = 'train', transform=None, modals=['img'], case=None) -> None:
        super().__init__()
        assert split in ['train', 'val', 'test']
        self.transform = transform
        self.n_classes = len(self.CLASSES)
        self.ignore_label = 255
        self.modals = modals
        self.files = sorted(glob.glob(os.path.join(*[root, 'img', '*', split, '*', '*.png'])))
        # --- debug
        # self.files = sorted(glob.glob(os.path.join(*[root, 'img', '*', split, '*', '*.png'])))[:100]
        # --- split as case
        if case is not None:
            assert case in ['cloud', 'fog', 'night', 'rain', 'sun', 'motionblur', 'overexposure', 'underexposure', 'lidarjitter', 'eventlowres'], "Case name not available."
            _temp_files = [f for f in self.files if case in f]
            self.files = _temp_files
        if not self.files:
            raise Exception(f"No images found in {root}")
        print(f"Found {len(self.files)} {split} {case} images.")

        self.transform_augment = transforms.Compose([
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1)  # Adjust color properties
        ])

    def __len__(self) -> int:
        return len(self.files)
    
    def __getitem__(self, index: int) -> Tuple[Tensor, Tensor]:
        rgb = str(self.files[index])
        x1 = rgb.replace('/img', '/hha').replace('_rgb', '_depth')
        x2 = rgb.replace('/img', '/lidar').replace('_rgb', '_lidar')
        x3 = rgb.replace('/img', '/event').replace('_rgb', '_event')
        lbl_path = rgb.replace('/img', '/semantic').replace('_rgb', '_semantic')

        sample = {}
        sample['img'] = io.read_image(rgb)[:3, ...]
        H, W = sample['img'].shape[1:]
        if 'depth' in self.modals:
            sample['depth'] = self._open_img(x1)
        if 'lidar' in self.modals:
            sample['lidar'] = self._open_img(x2)
        if 'event' in self.modals:
            eimg = self._open_img(x3)
            sample['event'] = TF.resize(eimg, (H, W), TF.InterpolationMode.NEAREST)
        label = io.read_image(lbl_path)[0, ...].unsqueeze(0)
        label[label == 255] = 0
        label -= 1
        sample['mask'] = label

        if self.transform:
            sample = self.transform(sample)
        label = sample['mask']
        del sample['mask']
        label = self.encode(label.squeeze().numpy()).long()
        sample = [sample[k] for k in self.modals]
        return sample, label

    def _open_img(self, file):
        img = io.read_image(file)
        C, H, W = img.shape
        if C == 4:
            img = img[:3, ...]
        if C == 1:
            img = img.repeat(3, 1, 1)
        return img

    def encode(self, label: Tensor) -> Tensor:
        """
        Remaps the original 25-class labels to the 11-class subset.
        """
        encoded_label = np.full_like(label, self.ignore_label, dtype=np.uint8)
        for original_idx, new_idx in self.CLASS_MAP.items():
            encoded_label[label == original_idx] = new_idx
        return torch.from_numpy(encoded_label)

if __name__ == '__main__':
    cases = ['cloud']
    #['cloud', 'fog', 'night', 'rain', 'sun', 'motionblur', 'overexposure', 'underexposure', 'lidarjitter', 'eventlowres']
    traintransform = get_train_augmentation((1024, 1024), seg_fill=255)
    cfg_path = '/root/2/configs/msda.yaml'
    with open(cfg_path) as f:
        cfg = yaml.load(f, Loader=yaml.SafeLoader)
    dataset_cfg = cfg['DATASET']
    print("dataset_cfg['NAME']:", dataset_cfg['NAME'])
    root = cfg['DATASET']['ROOT_s']
    cfg = cfg['DATASET']
    for case in cases:
        trainset = eval(dataset_cfg['NAME'])(dataset_cfg['ROOT_s'], 'test', traintransform, dataset_cfg['MODALS'], case)
        trainloader = DataLoader(trainset, batch_size=2, num_workers=2, drop_last=False, pin_memory=False)
        for i, (sample, lbl) in enumerate(trainloader):
            print(torch.unique(lbl))

