import os
import torch 
import argparse
import yaml
import time
import random
import multiprocessing as mp
from tabulate import tabulate
from tqdm import tqdm
from torch.utils.data import DataLoader
from pathlib import Path
from torch.utils.tensorboard import SummaryWriter
from torch.cuda.amp import GradScaler, autocast
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DistributedSampler, RandomSampler
from torch import distributed as dist
from semseg.models import *
from semseg.datasets import * 
from semseg.augmentations_mm import get_train_augmentation, get_val_augmentation
from semseg.losses import get_loss
from semseg.schedulers import get_scheduler
from semseg.optimizers import get_optimizer
from semseg.utils.utils import fix_seeds, setup_cudnn, cleanup_ddp, setup_ddp, get_logger, cal_flops, print_iou
from tools.val_mm import evaluate

import torch.nn as nn
from torch.nn import functional as F

def main(cfg, gpu, save_dir):
    start = time.time()
    best_mIoU = 0.0
    best_mIoU_t = 0.0
    best_epoch = 0
    num_workers = 8
    device = torch.device(cfg['DEVICE'])
    train_cfg, eval_cfg = cfg['TRAIN'], cfg['EVAL']
    dataset_cfg, model_cfg = cfg['DATASET'], cfg['MODEL']
    loss_cfg, optim_cfg, sched_cfg = cfg['LOSS'], cfg['OPTIMIZER'], cfg['SCHEDULER']
    epochs, lr = train_cfg['EPOCHS'], optim_cfg['LR']
    resume_path = cfg['MODEL']['RESUME']
    gpus = int(os.environ['WORLD_SIZE']) 

    traintransform = get_train_augmentation(train_cfg['IMAGE_SIZE'], seg_fill=dataset_cfg['IGNORE_LABEL'])
    valtransform = get_val_augmentation(eval_cfg['IMAGE_SIZE'])

    trainset_source = eval(dataset_cfg['NAME_SOURCE'])(dataset_cfg['ROOT_SOURCE'], 'train', traintransform, dataset_cfg['MODALS_SOURCE'])
    valset_source = eval(dataset_cfg['NAME_SOURCE'])(dataset_cfg['ROOT_SOURCE'], 'val', valtransform, dataset_cfg['MODALS_SOURCE'])
    class_names = trainset_source.CLASSES

    trainset_target = eval(dataset_cfg['NAME_TARGET'])(dataset_cfg['ROOT_TARGET'], 'train', traintransform, dataset_cfg['MODALS_TARGET'])
    valset_target = eval(dataset_cfg['NAME_TARGET'])(dataset_cfg['ROOT_TARGET'], 'val', valtransform, dataset_cfg['MODALS_TARGET'])
    # class_names_t = valset_t.CLASSES

    model = eval(model_cfg['NAME'])(model_cfg['BACKBONE'], trainset_source.n_classes, dataset_cfg['MODALS_SOURCE'])
    # model.init_pretrained(model_cfg['PRETRAINED'])
    # model_path = "/root/2/pretrained/Fusion_Fusion-B0_MSDADELIVER_epoch188_51.38.pth"
    # model_path = '/root/2/output/b2-deliver-pre/MSDADELIVER_Fusion-B2_iel/Fusion_Fusion-B2_MSDADELIVER_epoch183_65.49.pth'
    model_path = '2/output/b0-uda-test/rgb-pre-b0-deliver/MSDADELIVER_Fusion-B0_i/Fusion_Fusion-B0_MSDADELIVER_epoch199_43.85.pth'
    model.load_state_dict(torch.load(model_path, map_location=torch.device("cpu")),strict=False)
    model = model.to(device)

    model_t = eval(model_cfg['NAME'])(model_cfg['BACKBONE'], trainset_source.n_classes, dataset_cfg['MODALS_SOURCE'])
    model_t.load_state_dict(torch.load(model_path, map_location=torch.device("cpu")),strict=False)
    # model_path = "/mnt/dev-ssd-8T/zheng/DELIVER/MSDA/exp/MSDA_DELIVER_Pre_RE/MSDADELIVER_CMNeXt-B0_ie/CMNeXt_CMNeXt-B0_MSDADELIVER_epoch163_78.45.pth"
    # model_t.load_state_dict(torch.load(model_path, map_location=torch.device("cpu")),strict=False)
    model_t = model_t.to(device)
    model_t.eval()

    iters_per_epoch_source = len(trainset_source) // train_cfg['BATCH_SIZE'] // gpus
    iters_per_epoch_target = len(trainset_target) // train_cfg['BATCH_SIZE'] // gpus
    loss_fn = get_loss(loss_cfg['NAME'], trainset_source.ignore_label, None)
    kl_loss = nn.KLDivLoss(size_average=None, reduce=None, reduction='mean', log_target=True)

    start_epoch = 0
    optimizer = get_optimizer(model, optim_cfg['NAME'], lr, optim_cfg['WEIGHT_DECAY'])
    iters_per_epoch = min(iters_per_epoch_source, iters_per_epoch_target)
    scheduler = get_scheduler(sched_cfg['NAME'], optimizer, int((epochs+1)*iters_per_epoch), sched_cfg['POWER'], iters_per_epoch * sched_cfg['WARMUP'], sched_cfg['WARMUP_RATIO'])

    if train_cfg['DDP']: 
        sampler_source = DistributedSampler(trainset_source, dist.get_world_size(), dist.get_rank(), shuffle=True)
        sampler_target = DistributedSampler(trainset_target, dist.get_world_size(), dist.get_rank(), shuffle=True)
        sampler_val = None
        model = DDP(model, device_ids=[gpu], output_device=0, find_unused_parameters=True)
    else:
        sampler_source = RandomSampler(trainset_source)
        sampler_target = RandomSampler(trainset_target)
        sampler_val = None

    trainloader_source = DataLoader(trainset_source, batch_size=train_cfg['BATCH_SIZE'], num_workers=num_workers, drop_last=True, pin_memory=False, sampler=sampler_source)
    trainloader_target = DataLoader(trainset_target, batch_size=train_cfg['BATCH_SIZE'], num_workers=num_workers, drop_last=True, pin_memory=False, sampler=sampler_target)
    valloader = DataLoader(valset_source, batch_size=eval_cfg['BATCH_SIZE'], num_workers=num_workers, pin_memory=False, sampler=sampler_val)
    valloader_t = DataLoader(valset_target, batch_size=eval_cfg['BATCH_SIZE'], num_workers=num_workers, pin_memory=False, sampler=sampler_val)

    scaler = GradScaler(enabled=train_cfg['AMP'])
    if (train_cfg['DDP'] and torch.distributed.get_rank() == 0) or (not train_cfg['DDP']):
        writer = SummaryWriter(str(save_dir))
        logger.info('================== training config =====================')
        logger.info(cfg)
    
    modals_target = dataset_cfg['MODALS_TARGET']
    modals_dict_target = {name: idx for idx, name in enumerate(modals_target)}
    modals_combos_target = [
    ['frame_camera'],
    ['event_camera'],
    ['lidar'],
    ['frame_camera', 'lidar'],
    ['frame_camera', 'event_camera'],
    ['event_camera', 'lidar'],
    ['frame_camera', 'event_camera', 'lidar'],
]

    for epoch in range(start_epoch, epochs):
        torch.cuda.empty_cache()
        model.train()
        if train_cfg['DDP']: sampler_source.set_epoch(epoch)

        train_loss = 0.0  
        train_loss_s = 0.0
        train_loss_t = 0.0
        lr = scheduler.get_lr()
        lr = sum(lr) / len(lr)
        
        min_iters = min(len(trainloader_source), len(trainloader_target))
        # print(len(trainloader), len(trainloader_t))
        pbar_source = tqdm(enumerate(trainloader_source), total=iters_per_epoch_source, desc=f"Epoch: [{epoch+1}/{epochs}] Iter: [{0}/{iters_per_epoch_source}] LR: {lr:.8f} Loss: {train_loss:.8f}")
        pbar_target = tqdm(enumerate(trainloader_target), total=iters_per_epoch_target, desc=f"Epoch: [{epoch+1}/{epochs}] Iter: [{0}/{iters_per_epoch_target}] LR: {lr:.8f} Loss: {train_loss:.8f}")

        for iter, (sample, lbl) in pbar_source:
            optimizer.zero_grad(set_to_none=True)
            lbl = lbl.to(device)
            sample = [x.to(device) for x in sample]
            
            with autocast(enabled=train_cfg['AMP']):
                s_logits_s = model(sample)
                t_logits_s = model_t(sample)
                # soft max
                log_q_student = F.log_softmax(s_logits_s, dim=1)        # 目标 P (概率)
                p_teacher = F.softmax(t_logits_s, dim=1) # 输入 log(Q)
                loss_s_kl = kl_loss(log_q_student, p_teacher)
                # loss_s_kl = kl_loss(t_logits_s, s_logits_s)
                loss_s_ce = loss_fn(s_logits_s, lbl)
                loss_s = loss_s_kl + loss_s_ce 

            scaler.scale(loss_s).backward()
            for param_group in optimizer.param_groups:
                lr_val = param_group['lr']
                if isinstance(lr_val, complex):
                    param_group['lr'] = abs(lr_val)
                param_group['lr'] = max(float(param_group['lr']), 1e-8)
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            torch.cuda.synchronize()

            lr = scheduler.get_lr()
            lr = sum(lr) / len(lr) 
            # Ensure lr is a float before comparison
            if isinstance(lr, complex):
                lr = abs(lr)  # Convert complex to its magnitude
            lr = float(lr)  # Ensure lr is a float
            lr = max(lr, 1e-8)
            train_loss += loss_s.item()
            train_loss_s += loss_s.item()

            pbar_source.set_description(f"Epoch: [{epoch+1}/{epochs}] Iter: [{iter+1}/{iters_per_epoch_source}] LR: {lr:.8f} Loss: {train_loss / (iter+1):.8f}")
        
        for iter, (sample_t, _) in pbar_target:
            optimizer.zero_grad(set_to_none=True)
            # label_t = label_t.to(device)
            sample_t = [x.to(device) for x in sample_t]
            
            with autocast(enabled=train_cfg['AMP']):
                pseudo_label_t = generate_fused_pseudo_label(
                    model_t=model_t,
                    sample_t=sample_t,
                    modal_combos=modals_combos_target,
                    modal_dict=modals_dict_target,
                    device=device
                )
                s_logits_t = model(sample_t)
                t_logits_t = model_t(sample_t)
                #t_logits_t = avg_pred
                # softmax
                log_q_student_t = F.log_softmax(s_logits_t, dim=1)
                p_teacher_t = F.softmax(t_logits_t, dim=1)
                loss_t_kl = kl_loss(log_q_student_t, p_teacher_t)  
                #loss_t = kl_loss(t_logits_t, s_logits_t)
                loss_t_ce = loss_fn(s_logits_t, pseudo_label_t)
                loss_t = loss_t_kl + loss_t_ce

            scaler.scale(loss_t).backward()
            for param_group in optimizer.param_groups:
                lr_val = param_group['lr']
                if isinstance(lr_val, complex):
                    param_group['lr'] = abs(lr_val)
                param_group['lr'] = max(float(param_group['lr']), 1e-8)
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            torch.cuda.synchronize()

            lr = scheduler.get_lr()
            lr = sum(lr) / len(lr) 
            # Ensure lr is a float before comparison
            if isinstance(lr, complex):
                lr = abs(lr)  # Convert complex to its magnitude
            lr = float(lr)  # Ensure lr is a float
            lr = max(lr, 1e-8)
            train_loss += loss_t.item()
            train_loss_t += loss_t.item()

            pbar_target.set_description(f"Epoch: [{epoch+1}/{epochs}] Iter: [{iter+1}/{iters_per_epoch_target}] LR: {lr:.8f} Loss: {train_loss / (iter+1):.8f}")
        
        train_loss /= (iters_per_epoch_source + iters_per_epoch_target)
        train_loss_s /= iters_per_epoch_source
        train_loss_t /= iters_per_epoch_target
        if (train_cfg['DDP'] and torch.distributed.get_rank() == 0) or (not train_cfg['DDP']):
            writer.add_scalar('train/loss', train_loss, epoch)
            writer.add_scalar('train_source/loss', train_loss_s, epoch)
            writer.add_scalar('train_target/loss', train_loss_t, epoch)

        if ((epoch+1) % train_cfg['EVAL_INTERVAL'] == 0 and (epoch+1)>train_cfg['EVAL_START']) or (epoch+1) == epochs:
            if (train_cfg['DDP'] and torch.distributed.get_rank() == 0) or (not train_cfg['DDP']):
                acc, macc, _, _, ious, miou = evaluate(model, valloader_t, device)
                writer.add_scalar('target_val/mIoU', miou, epoch)

                if miou > best_mIoU:
                    prev_best_ckp = save_dir / f"{model_cfg['NAME']}_{model_cfg['BACKBONE']}_{dataset_cfg['NAME_TARGET']}_epoch{best_epoch}_{best_mIoU}_checkpoint.pth"
                    prev_best = save_dir / f"{model_cfg['NAME']}_{model_cfg['BACKBONE']}_{dataset_cfg['NAME_TARGET']}_epoch{best_epoch}_{best_mIoU}.pth"
                    if os.path.isfile(prev_best): os.remove(prev_best)
                    if os.path.isfile(prev_best_ckp): os.remove(prev_best_ckp)
                    best_mIoU = miou
                    best_epoch = epoch+1
                    cur_best_ckp = save_dir / f"{model_cfg['NAME']}_{model_cfg['BACKBONE']}_{dataset_cfg['NAME_TARGET']}_epoch{best_epoch}_{best_mIoU}_checkpoint.pth"
                    cur_best = save_dir / f"{model_cfg['NAME']}_{model_cfg['BACKBONE']}_{dataset_cfg['NAME_TARGET']}_epoch{best_epoch}_{best_mIoU}.pth"
                    torch.save(model.module.state_dict() if train_cfg['DDP'] else model.state_dict(), cur_best)
                    # ---  
                    torch.save({'epoch': best_epoch,
                                'model_state_dict': model.module.state_dict() if train_cfg['DDP'] else model.state_dict(),
                                'optimizer_state_dict': optimizer.state_dict(),
                                'loss': train_loss,
                                'scheduler_state_dict': scheduler.state_dict(),
                                'best_miou': best_mIoU,
                                }, cur_best_ckp)
                    logger.info(print_iou(epoch, ious, miou, acc, macc, class_names))

                    # Source Evaluation
                    acc, macc, _, _, ious, miou = evaluate(model, valloader, device)
                    writer.add_scalar('source_val/mIoU', miou, epoch)
                    print("DELIVER Evaluation Performance")
                    logger.info(print_iou(epoch, ious, miou, acc, macc, class_names))
                   
                logger.info(f"Current epoch:{epoch} mIoU: {miou} Best mIoU: {best_mIoU}")
        

    if (train_cfg['DDP'] and torch.distributed.get_rank() == 0) or (not train_cfg['DDP']):
        writer.close()
    pbar_source.close()
    pbar_target.close()
    end = time.gmtime(time.time() - start)

    table = [
        ['Best mIoU', f"{best_mIoU:.2f}"],
        ['Total Training Time', time.strftime("%H:%M:%S", end)]
    ]
    logger.info(tabulate(table, numalign='right'))


def generate_fused_pseudo_label(model_t, sample_t, modal_combos, modal_dict, device):
    preds = []

    with torch.no_grad():
        for combo in modal_combos:
            input_combo = [sample_t[modal_dict[m]].to(device) for m in combo]
            while len(input_combo) < 3:
                # duplicate = sample_t[modal_dict['frame_camera']]
                duplicate = random.choice(input_combo)
                input_combo.append(duplicate.clone())
            output = model_t(input_combo)
            prob = F.softmax(output, dim=1)  # use last stage output
            preds.append(prob)

    # votes
    votes = [p.argmax(dim=1) for p in preds]         # 每个是 [B,H,W]
    votes_stack = torch.stack(votes, dim=0)          # [N, B, H, W]
    mode, counts = votes_stack.mode(dim=0)           # mode: [B,H,W], counts: [B,H,W]
    mask = counts >= 2                               # 至少两个组合一致
    pseudo = mode.clone()
    pseudo[~mask] = 255  # 255为ignore label

    return pseudo


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg', type=str, default='configs/deliver_rgbdel.yaml', help='Configuration file to use')
    args = parser.parse_args()

    with open(args.cfg) as f:
        cfg = yaml.load(f, Loader=yaml.SafeLoader)

    fix_seeds(3407)
    setup_cudnn()
    gpu = setup_ddp()
    modals = ''.join([m[0] for m in cfg['DATASET']['MODALS_SOURCE']])
    model = cfg['MODEL']['BACKBONE']
    exp_name = '_'.join([cfg['DATASET']['NAME_SOURCE'], model, modals])
    save_dir = Path(cfg['SAVE_DIR'], exp_name)
    if os.path.isfile(cfg['MODEL']['RESUME']):
        save_dir =  Path(os.path.dirname(cfg['MODEL']['RESUME']))
    os.makedirs(save_dir, exist_ok=True)
    logger = get_logger(save_dir / 'train.log')
    main(cfg, gpu, save_dir)
    cleanup_ddp()
