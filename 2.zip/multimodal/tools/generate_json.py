import os
import json
import glob
import numpy as np
from tqdm import tqdm
from torchvision import io
from collections import defaultdict

# ⚙️ CONFIG：请根据你的路径调整
DATA_ROOT = '/Users/zhangzelin/Documents/data/deliver/DELIVER'
SEMANTIC_DIR = os.path.join(DATA_ROOT, 'semantic')
OUTPUT_DIR = DATA_ROOT
IGNORE_LABEL = 255

# ✅ 使用你在 MSDADELIVER 中定义的 CLASS_MAP
CLASS_MAP = {
    0: 0,  # Building
    1: 2,  # Fence
    2: 255,  # Other -> Ignored
    3: 255,  # Pedestrian -> Ignored
    4: 3,  # Pole
    5: 255,  # RoadLine -> Ignored
    6: 4,  # Road
    7: 5,  # Sidewalk
    8: 9,  # Vegetation
    9: 255,  # Cars -> Ignored
    10: 10,  # Wall
    11: 255,  # TrafficSign -> Ignored
    12: 6,  # Sky
    13: 255,  # Ground -> Ignored
    14: 255,  # Bridge -> Ignored
    15: 255,  # RailTrack -> Ignored
    16: 255,  # GroundRail -> Ignored
    17: 255,  # TrafficLight -> Ignored
    18: 255,  # Static -> Ignored
    19: 255,  # Dynamic -> Ignored
    20: 255,  # Water -> Ignored
    21: 7,  # Terrain
    22: 255,  # TwoWheeler -> Ignored
    23: 1,  # Bus
    24: 8   # Truck
}

def get_all_label_paths(root_dir):
    return sorted(glob.glob(os.path.join(root_dir, '*', '*', '*', '*.png')))

def main():
    label_paths = get_all_label_paths(SEMANTIC_DIR)
    print(f"Found {len(label_paths)} semantic label files")

    sample_class_stats = []
    samples_with_class = defaultdict(list)

    for label_path in tqdm(label_paths):
        mask = io.read_image(label_path)[0].numpy()
        relative_path = os.path.relpath(label_path, SEMANTIC_DIR)

        # 原始标签中，忽略掉 255
        orig_ids, counts = np.unique(mask[mask != IGNORE_LABEL], return_counts=True)

        label_stat = {"file": relative_path}

        for orig_id, count in zip(orig_ids, counts):
            mapped_id = CLASS_MAP.get(orig_id, 255)
            if mapped_id == 255:
                continue
            label_stat[str(mapped_id)] = int(count)
            samples_with_class[mapped_id].append([relative_path, int(count)])

        sample_class_stats.append(label_stat)

    # 输出文件路径
    sample_stats_path = os.path.join(OUTPUT_DIR, 'sample_class_stats.json')
    samples_with_class_path = os.path.join(OUTPUT_DIR, 'samples_with_class.json')

    with open(sample_stats_path, 'w') as f:
        json.dump(sample_class_stats, f, indent=2)
    with open(samples_with_class_path, 'w') as f:
        json.dump(samples_with_class, f, indent=2)

    print(f"✅ Saved: {sample_stats_path}")
    print(f"✅ Saved: {samples_with_class_path}")

if __name__ == "__main__":
    main()
